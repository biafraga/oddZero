const urlAtual = new URL(window.location.href);
const siteOriginal = urlAtual.searchParams.get("site");

if (siteOriginal) {
  document.getElementById("nome-do-site").textContent =
    decodeURIComponent(siteOriginal);
}