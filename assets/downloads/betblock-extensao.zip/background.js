const dominiosBloqueados = [
  "facebook.com",
  "instagram.com",
  "x.com",
  "twitter.com"
];

const palavrasBloqueadas = [
  "bet",
  "betano",
  "bet365",
  "sportingbet",
  "pixbet",
  "stake",
  "casino",
  "cassino",
  "apostas",
  "aposta",
  "novibet",
  "esportesdasorte"
];

const regexApostas = new RegExp(
  `(^|[-.])(${palavrasBloqueadas.join("|")})([-.]|\\d|$)`,
  "i"
);

function obterDominioBloqueado(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();

    const dominio = hostname.replace(/^www\./, "");

    // 1. Bloqueio por domínio explícito
    const dominioEncontrado = dominiosBloqueados.find(site =>
      dominio === site ||
      dominio.endsWith(`.${site}`)
    );

    if (dominioEncontrado) {
      return dominioEncontrado;
    }

    // 2. Bloqueio automático por regex
    if (regexApostas.test(dominio)) {
      return dominio;
    }

    return null;
  } catch {
    return null;
  }
}

chrome.webNavigation.onBeforeNavigate.addListener(details => {
  if (details.frameId !== 0) {
    return;
  }

  if (details.url.startsWith(chrome.runtime.getURL(""))) {
    return;
  }

  const dominioBloqueado = obterDominioBloqueado(details.url);

  if (!dominioBloqueado) {
    return;
  }

  chrome.tabs.update(details.tabId, {
    url: chrome.runtime.getURL(
      `bloqueado.html?site=${encodeURIComponent(dominioBloqueado)}`
    )
  });
});